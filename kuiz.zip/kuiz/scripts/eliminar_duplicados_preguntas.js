// Script para eliminar preguntas duplicadas por el campo "pregunta" en banco_preguntas_certificacion.json
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/banco_preguntas_certificacion.json');
const outputPath = path.join(__dirname, '../data/banco_preguntas_certificacion_sin_duplicados.json');

const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
const seen = new Set();
const filtered = [];

for (const pregunta of data) {
  if (!seen.has(pregunta.pregunta)) {
    seen.add(pregunta.pregunta);
    filtered.push(pregunta);
  }
}

fs.writeFileSync(outputPath, JSON.stringify(filtered, null, 2), 'utf8');
console.log(`Preguntas filtradas: ${filtered.length}. Archivo generado: banco_preguntas_certificacion_sin_duplicados.json`);
