const fs = require('fs');

const encrypt = (text) => {
  // This is a placeholder for a real encryption algorithm
  const reversed = text.split("").reverse().join("");
  return `ENCRYPTED:${reversed}`;
};

fs.readFile('cuestionario.json', 'utf8', (err, data) => {
  if (err) {
    console.error(err);
    return;
  }

  const cuestionario = JSON.parse(data);

  const encryptedCuestionario = JSON.stringify(cuestionario.map(pregunta => ({
    ...pregunta,
    pregunta: encrypt(pregunta.pregunta),
    justificaciones: pregunta.justificaciones ? Object.fromEntries(
      Object.entries(pregunta.justificaciones).map(([key, value]) => [key, encrypt(value)])
    ) : null
  })));

  fs.writeFile('cuestionario_encriptado.json', encryptedCuestionario, err => {
    if (err) {
      console.error(err);
    } else {
      console.log('Cuestionario encriptado y guardado en cuestionario_encriptado.json');
    }
  });
});