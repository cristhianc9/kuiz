const fs = require('fs');

function generarCuestionarioTexto() {
  const cuestionario = JSON.parse(fs.readFileSync('cuestionario.json', 'utf-8'));
  const numPreguntas = 25;
  const saltoDeLinea = String.fromCharCode(13, 10);
  let textoContent = 'CUESTIONARIO DE ESTÁNDARES DE DESARROLLO\\r\\n\\r\\n';

  // Función para seleccionar preguntas aleatorias sin repetición
  function seleccionarPreguntasAleatorias(array, n) {
    const shuffled = array.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, n);
  }

  const preguntasSeleccionadas = seleccionarPreguntasAleatorias(cuestionario, numPreguntas);

  preguntasSeleccionadas.forEach((pregunta, preguntaIndex) => {
    textoContent += `Pregunta ${preguntaIndex + 1}: ${pregunta.pregunta}` + saltoDeLinea;

    if (pregunta.tipo === 'multiple') {
      pregunta.opciones.forEach((opcion, opcionIndex) => {
        textoContent += `${pregunta.respuesta.includes(opcion.id) ? '*' : ' '} ${opcionIndex + 1}) ${opcion.texto}` + saltoDeLinea;
      });
    } else if (pregunta.tipo === 'verdadero_falso') {
      textoContent += `${pregunta.respuesta ? '*' : ' '} 1) Verdadero` + saltoDeLinea;
      textoContent += `${!pregunta.respuesta ? '*' : ' '} 2) Falso` + saltoDeLinea;
    }

    textoContent += saltoDeLinea;
  });

  fs.writeFileSync('cuestionario.txt', textoContent);
  console.log('Archivo cuestionario.txt generado exitosamente.');
}

generarCuestionarioTexto();