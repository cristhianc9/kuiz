# Plan de Creación del Cuestionario SRI (Resumen Ejecutivo)

Este documento resume de manera concisa el plan para el desarrollo de un cuestionario de evaluación de conocimientos técnicos y un sitio web interactivo para desarrolladores de software en el Servicio de Rentas Internas (SRI).

## I. Objetivo General

Crear un cuestionario robusto para evaluar candidatos en Java, JEE7, JBoss EAP, Oracle y Red Hat RHEL 9, basado en estándares internos, y desarrollar un sitio web para la práctica y realización segura del examen.

## II. Fases Clave del Proyecto

### 1. Recopilación y Estructuración de Contenido

*   **Análisis de Estándares:** Se extrajo información relevante de documentos técnicos del SRI (`.pdf`) para identificar temas clave en Java, JEE7, JBoss EAP, Oracle y Red Hat RHEL 9.
*   **Definición de Formato:** El cuestionario incluirá preguntas de opción múltiple y verdadero/falso.
*   **Organización de Temas:** Los estándares se agruparon por temas para facilitar la creación de preguntas.

### 2. Diseño y Creación del Cuestionario

*   **Redacción de Preguntas:** Elaboración de preguntas y distractores basados en los estándares y temas identificados.
*   **Estructura de Datos:** Definición de un esquema JSON para almacenar preguntas, opciones, respuestas correctas y justificaciones.
*   **Seguridad de Datos:** Implementación de encriptación (ej. AES) para el archivo JSON de preguntas y respuestas, con gestión segura de la clave.

### 3. Desarrollo del Sitio Web Interactivo

*   **Tecnologías:** Desarrollo front-end utilizando HTML, CSS y JavaScript puro (sin frameworks).
*   **Lógica del Examen:** Implementación de la presentación de preguntas, captura de respuestas, evaluación automática y visualización de resultados.
*   **Gestión de Progreso:** Uso de `SessionStorage` para guardar el progreso del usuario durante la sesión, permitiendo retomar el examen.
*   **Generación de PDF:** Integración de `jsPDF` para generar informes PDF con los resultados del cuestionario, incluyendo información del participante en cada página (encabezado/pie de página) y en el nombre del archivo.
*   **Temporizador por Pregunta:** Implementación de un temporizador configurable (60 segundos por pregunta) con una barra de progreso horizontal. Al agotarse el tiempo, la pregunta se marca como incorrecta, pero el usuario puede seguir interactuando.
*   **Indicador de Progreso:** Visualización del avance del quiz mediante indicadores de puntos/círculos.
*   **Mejoras de Diseño (UX/UI):**
    *   Optimización del espaciado vertical en CSS para asegurar la visibilidad de las preguntas sin scroll.
    *   Reubicación de la información general y la barra de progreso/temporizador a una disposición lateral (dos columnas) en pantallas de escritorio, con responsividad para móviles.
    *   Ajustes de estilos para una interfaz intuitiva, atractiva y accesible (paleta de colores, tipografía, contraste, etiquetas claras).
*   **Seguridad del Sitio:** Protección de preguntas y respuestas contra accesos no autorizados.
*   **Rendimiento y Pruebas:** Optimización del código para un rendimiento fluido y realización de pruebas exhaustivas.

## III. Diagrama de Flujo General del Proceso

```mermaid
graph TD
    A[Inicio] --> B(Recopilación y Análisis de Información);
    B --> C(Creación del Cuestionario);
    C --> D(Desarrollo del Sitio Web);
    D --> E(Pruebas y Refinamiento);
    E --> F[Finalización del Proyecto];