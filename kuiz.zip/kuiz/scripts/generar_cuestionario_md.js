const fs = require('fs');

function generarCuestionarioMarkdown() {
  const cuestionario = JSON.parse(fs.readFileSync('cuestionario.json', 'utf-8'));
  const temas = {};

  cuestionario.forEach(item => {
    if (!temas[item.tema]) {
      temas[item.tema] = [];
    }
    temas[item.tema].push(item);
  });

  let markdownContent = '# Cuestionario por Temas\\n\\n';

  for (const tema in temas) {
    markdownContent += `## ${tema}\\n\\n`;
    temas[tema].forEach((pregunta, index) => {
      markdownContent += `### Pregunta ${index + 1}\\n\\n`;
      markdownContent += `${pregunta.pregunta}\\n\\n`;

      if (pregunta.tipo === 'multiple') {
        pregunta.opciones.forEach((opcion, opcionIndex) => {
          markdownContent += `- ${pregunta.respuesta.includes(opcion.id) ? '[x]' : '[ ]'} ${opcion.texto}\\n`;
        });
      } else if (pregunta.tipo === 'verdadero_falso') {
        markdownContent += `- ${pregunta.respuesta === 'verdadero' ? '[x]' : '[ ]'} Verdadero\\n`;
        markdownContent += `- ${pregunta.respuesta === 'falso' ? '[x]' : '[ ]'} Falso\\n`;
      }

      markdownContent += `\\n**Justificación:** ${pregunta.justificaciones ? Object.values(pregunta.justificaciones).join(', ') : ''}\\n\\n`;
    });
  }

  fs.writeFileSync('cuestionario_por_tema.md', markdownContent);
  console.log('Archivo cuestionario_por_tema.md generado exitosamente.');
}

generarCuestionarioMarkdown();